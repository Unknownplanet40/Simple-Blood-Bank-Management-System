<!DOCTYPE html>
<html>

<head>
    <title> About Me </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Stylesheet/Bragaiz_HP_Style.css">
</head>

<body>
    <div class="banner">
        <div class="navbar">
            <img width="140px" height="100px" style="border-radius 5%;" src="../images/Apex.png" class="logo">
            <ul>
                <li><a href="../Portfolio/Bragaiz_HP_Portfolio.php">Home</a></li>
                <li><a href="../Portfolio/Bragaiz_F_Portfolio.php">Family</a></li>
                <li><a href="../Portfolio/Bragaiz_H_Portfolio.php">Hobbies</a></li>
                <li><a href="../Home/HomePage.php">Back</a></li>
            </ul>
        </div>

        <div class="content">
            <h1>About Me </h1>
            <p>Hi! Im student in cavite state university and my course and year is 1st Year College in Bachelor of
                Science in Information Technology in cavite state university. And i love long rides and cycling race i
                have one brother. And im living in imus cavite. My favorite food is chicken in
                jollibee,BBQ,Menudo,Caldereta and more. My favorite color is black,red,yellow,green and blue. And i hate
                toxic people. Just stay positive and stay motivated anytime.</p>
            <div>


            </div>

        </div>

</body>

</html>