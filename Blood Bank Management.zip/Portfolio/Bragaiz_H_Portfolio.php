<!DOCTYPE html>
<html>

<head>
    <title> My Hobbies </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Stylesheet/Bragaiz_HP_Style.css">
</head>

<body>
    <div class="banner">
        <div class="navbar">
            <img width="140px" height="100px" style="border-radius 5%;" src="../images/Apex.png" class="logo">
            <ul>
                <li><a href="../Portfolio/Bragaiz_HP_Portfolio.php">Home</a></li>
                <li><a href="../Portfolio/Bragaiz_F_Portfolio.php">Family</a></li>
                <li><a href="../Portfolio/Bragaiz_AM_Portfolio.php">About Me</a></li>
                <li><a href="../Home/HomePage.php">Back</a></li>
            </ul>
        </div>

        <div class="content">
            <h1>My Hobbies </h1>
            <p>My favorite hobby is long rides and cycling race but now i dont bike anymore and i play basketball and
                riding a motor. *cool scenery, *awesome views, *meet strong cyclist and amazing people, *less my stress
                in school. The benefits of cycling are numerous not just for the person peddling but for the
                environment, therefore, society as a whole too. It’s a heart health hobby that enhances brain activity
                and reduces carbon gas release. It’s also a fun outdoor activity that stimulates the senses which are
                dulled by staying indoors too close to the television and refrigerator. Unlike both swimming and
                running, cyclists can enjoy a conversation with a fellow rider. My other hobbies is core work and out
                leg work out and watching movies hangout with friends and playing game if have time.</p>
            <div>

            </div>

        </div>

    </div>

</body>

</html>