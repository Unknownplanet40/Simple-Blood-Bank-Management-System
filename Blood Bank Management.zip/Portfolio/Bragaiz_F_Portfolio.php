<!DOCTYPE html>
<html>

<head>
    <title> My Family</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Stylesheet/Bragaiz_HP_Style.css">
</head>

<body>
    <div class="banner">
        <div class="navbar">
            <img width="140px" height="100px" style="border-radius 5%;" src="../images/Apex.png" class="logo">
            <ul>
                <li><a href="../Portfolio/Bragaiz_HP_Portfolio.php">Home</a></li>
                <li><a href="../Portfolio/Bragaiz_AM_Portfolio.php">About Me</a></li>
                <li><a href="../Portfolio/Bragaiz_H_Portfolio.php">Hobbies</a></li>
                <li><a href="../Home/HomePage.php">Back</a></li>
            </ul>
        </div>

        <div class="content">
            <h1>My Family </h1>
            <p>my family is important to me because it gives me the warmth, love and affection that you may not get
                anywhere in the world. Family teaches the high moral values in life and makes you a better human being.
                And my father inspires me with his hard work, honesty and diligence. He is very loving and caring and
                binds the entire family together. I thank God and am very grateful for the most precious gift of family
                because family members give unconditional love, care and affection. I am what I am because of my family.
                My family completes me.</p>
            <div>

            </div>

        </div>

    </div>

</body>

</html>