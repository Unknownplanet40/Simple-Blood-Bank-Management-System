# Blood Bank Management System
> Project for DCIT-24A 1st Semester Finals

## Instructions
1. Import the database file to your phpmyadmin <sup>`Very Important`</sup>
2. put the project folder in your htdocs folder 
   > `(C:\xampp\htdocs\Blood Bank Management System)`
3. Run the project in your browser
   > `http://localhost/Blood Bank Management System/Home/HomePage.php`

## Database
- Database name: `bloodbank_management`
- Tables: `user`, `request`, `donation`, `blood_types`, `portfolio_database`